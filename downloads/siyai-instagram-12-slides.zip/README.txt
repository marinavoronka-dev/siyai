СИЯЙ! — 3 карусели для Instagram

01-znakomstvo — Знакомство с приложением
02-ustanovka — Как установить на Android
03-otzyvy — Как оставить отзыв

В каждой папке 4 слайда. Загружайте в порядке 01.png, 02.png, 03.png, 04.png.

Добавьте в профиль ссылку: https://siyai-mia-beauty.sappyoasis1.chatgpt.site/download/

PNG-файлы сохранены без изменения оригиналов.
